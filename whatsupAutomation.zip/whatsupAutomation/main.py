import pywhatkit
pywhatkit.sendwhatmsg(" +8801742336806 ", " Hello Brother !!! ", 18, 42)

