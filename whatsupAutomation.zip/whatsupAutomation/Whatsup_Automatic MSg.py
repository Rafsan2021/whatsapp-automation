# pip install pywhatkit
import pywhatkit
pywhatkit.sendwhatmsg(" +8801911600975 ", " Monu ki khobor.... ?? ", 20, 36)

